package aiPlugin.api;

public interface MyPluginComponent
{
    String getName();
}