package aiPlugin.servlet;


import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.issue.IssueInputParameters;
import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.user.ApplicationUser;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class TestCaseServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String issueKey = req.getParameter("issueKey");
        if (issueKey == null || issueKey.isEmpty()) {
            resp.sendError(400, "Missing issueKey");
            return;
        }

        MutableIssue issue = ComponentAccessor.getIssueManager().getIssueByCurrentKey(issueKey);
        ApplicationUser user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser();

        String apiUrl = "https://your-api.com/get-test-cases?storyKey=" + issueKey;
        URL url = new URL(apiUrl);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");

        if (con.getResponseCode() != 200) {
            resp.sendError(502, "Failed to fetch test cases");
            return;
        }

        Scanner scanner = new Scanner(con.getInputStream()).useDelimiter("\\A");
        String response = scanner.hasNext() ? scanner.next() : "";
        scanner.close();

        JSONArray testCases = new JSONArray(response); // expected: [{"id": 1, "name": "TC_001"}, ...]

        // Join test case names into a string
        StringBuilder sb = new StringBuilder("Linked Test Cases:\n");
        for (int i = 0; i < testCases.length(); i++) {
            JSONObject tc = testCases.getJSONObject(i);
            sb.append("- ").append(tc.getString("name")).append("\n");
        }

        // Add as a comment
        ComponentAccessor.getCommentManager().create(issue, user, sb.toString(), true);

        resp.setContentType("text/plain");
        resp.getWriter().write("✅ Test cases linked to " + issueKey);
    }
}
