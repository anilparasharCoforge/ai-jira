package aiPlugin.servlet;


import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class ExternalDataServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

        String apiUrl = "https://your-api.com/data"; // External API URL
        HttpURLConnection con = (HttpURLConnection) new URL(apiUrl).openConnection();
        con.setRequestMethod("GET");

        int status = con.getResponseCode();
        if (status != 200) {
            resp.sendError(502, "Failed to fetch data");
            return;
        }

        Scanner scanner = new Scanner(con.getInputStream()).useDelimiter("\\A");
        String result = scanner.hasNext() ? scanner.next() : "";
        scanner.close();

        resp.setContentType("application/json");
        resp.getWriter().write(result);
    }
}
