AJS.toInit(function () {
  fetch('/plugins/servlet/external-data')
    .then(response => response.json())
    .then(data => {
      let html = "<ul>";
      data.items.forEach(item => {
        html += `<li>${item.name} - ${item.status}</li>`;
      });
      html += "</ul>";
      document.getElementById("data-container").innerHTML = html;
    })
    .catch(err => {
      document.getElementById("data-container").innerHTML = "Error loading data.";
    });
});


http://10.7.6.4:5005/docs